package uniandes.cupi2.sintetizador.interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class PanelInformacion extends JPanel implements ActionListener {
	
	
	
	private InterfazSintetizador sintetizador;
	private JLabel descripcion;
	private JTextField sonidos;
	private JTextField puntajes;
	
	private JLabel calificacion;
	private JButton guardar;
	private JCheckBox favoritos;
	private JCheckBox fantasia;
	private JCheckBox divertidos;
	
			
	
	public PanelInformacion(InterfazSintetizador pSintetizador){
		
		sintetizador=pSintetizador;
		
		setLayout(new GridLayout(2,1));
		JPanel panelArriba = new JPanel();
		panelArriba.setLayout(new GridLayout(4,1));
		setPreferredSize( new Dimension( 200, 200) );
		
		
		
		descripcion=new JLabel("Descripcion");
		panelArriba.add(descripcion);
	
		sonidos=new JTextField("");
		sonidos.setEditable(false);
		panelArriba.add(sonidos);
		
		calificacion=new JLabel("Calificacion");
		panelArriba.add(calificacion);
		
		puntajes=new JTextField("");
		puntajes.setEditable(false);
		panelArriba.add(puntajes);
		
		add(panelArriba);
		
		JPanel panelAbajo=new JPanel();
		panelAbajo.setLayout(new GridLayout(4,1));
	    panelAbajo.setBorder(new TitledBorder("Grupos a los que pertenece"));
	    panelAbajo.setSize(200,200);
	    
	    favoritos=new JCheckBox("Favoritos");
	    panelAbajo.add(favoritos);
	    
	    fantasia=new JCheckBox("Fantasia");
	    panelAbajo.add(fantasia);
	    
	    divertidos=new JCheckBox("Divertidos");
	    panelAbajo.add(divertidos);
	    
	    
	    guardar=new JButton("guardar");
	    panelAbajo.add(guardar);
	    
	    
	    
	    add(panelAbajo);
		
		
		
		
		
		
		
	}
	
	
	
	public void actualizar(String pDescripcion, String pCalificacion){
		sonidos.setText(pDescripcion);
		puntajes.setText(pCalificacion);
		
		
		
		
		
		
	}



	@Override
	public void actionPerformed(ActionEvent pEvento) {
		
		String comando= pEvento.getActionCommand();
		
		
		if(comando.equals("guardar")){
		boolean fav=favoritos.isSelected();
		boolean fant=fantasia.isSelected();
		boolean div=fantasia.isSelected();
		sintetizador.guardar(fav, fant, div);
		}
		
		
		
	}
	
	
	
	
	
	

}
