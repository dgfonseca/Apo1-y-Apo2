package uniandes.cupi2.sintetizador.interfaz;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelTeclado extends JPanel implements ActionListener {
	
	private final static String DO1="./data/teclas/do4.png";
	private final static String DO2="./data/teclas/do5.png";
	private final static String FA="./data/teclas/fa4.png";
	private final static String LA="./data/teclas/la4.png";
	private final static String MI="./data/teclas/mi4.png";
	private final static String RE="./data/teclas/re4.png";
	private final static String SOL="./data/teclas/sol4.png";
	private final static String SI="./data/teclas/si4.png";
	
	private InterfazSintetizador sintetizador;
	private JButton do1;
	private JButton do2;
	private JButton re;
	private JButton mi;
	private JButton fa;
	private JButton sol;
	private JButton la;
	private JButton si;
	
	
	public PanelTeclado(InterfazSintetizador pSintetizador ){
		setLayout(new GridLayout(1, 8));
		sintetizador=pSintetizador;
		
		for(int i=0; i<sintetizador.darNotas().length; i++){
			JButton boton= new JButton();
			ImageIcon icon = new ImageIcon(sintetizador.darNotas()[i].darRutaImagen());
			boton.setIcon(icon);
			boton.setActionCommand(sintetizador.darNotas()[i].darNombre());
			boton.addActionListener(this);
			add(boton);
			
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@Override
	public void actionPerformed(ActionEvent pEvento) {
		
		String comando=pEvento.getActionCommand();
		sintetizador.reproducir(comando);
		
		
	}
	

}
