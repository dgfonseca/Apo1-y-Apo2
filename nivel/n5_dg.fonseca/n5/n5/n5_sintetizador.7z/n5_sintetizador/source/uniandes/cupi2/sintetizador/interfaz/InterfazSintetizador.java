package uniandes.cupi2.sintetizador.interfaz;
import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.*;

import uniandes.cupi2.sintetizador.mundo.Efecto;
import uniandes.cupi2.sintetizador.mundo.Nota;
import uniandes.cupi2.sintetizador.mundo.Sintetizador;

public class InterfazSintetizador extends JFrame {
	//Atributos
	private Sintetizador sintetizador; 	
	//atributos de la interfaz
	private PanelEfectos panelEfectos;
	private PanelInformacion panelInformacion;
	private PanelOpciones panelOpciones;
	private PanelSuperior panelSuperior;
	private PanelTeclado panelTeclado;

	public InterfazSintetizador() throws Exception{
		try{
			setTitle("Sintetizador");
			setSize(1000,600);
			setResizable(false);
			setDefaultCloseOperation( EXIT_ON_CLOSE );

			//crea el sintetizador
			sintetizador= new Sintetizador();
			setLayout(new BorderLayout());

			//panel teclado
			panelTeclado=new PanelTeclado(this);
			add(panelTeclado, BorderLayout.CENTER);

			//Panel Efectos
			panelEfectos=new PanelEfectos(this);
			add(panelEfectos, BorderLayout.WEST);



			//panel informacion
			panelInformacion=new PanelInformacion(this);
			add(panelInformacion, BorderLayout.EAST);

			//panel opciones
			panelOpciones=new PanelOpciones(this);
			add(panelOpciones, BorderLayout.SOUTH);

			//panel superior
			panelSuperior=new PanelSuperior(this);
			add(panelSuperior, BorderLayout.NORTH);









		}
		catch(Exception e){
			e.printStackTrace( );
			JOptionPane.showMessageDialog( this, e.getMessage( ), "Sintetizador", JOptionPane.ERROR_MESSAGE );
		}

	}
	
	public void darAnterior() throws Exception{
		try {
			sintetizador.darAnteriorEfecto();
			Efecto efectoActual = sintetizador.darEfectoActual();
			panelSuperior.actualizar(efectoActual);
			System.out.println(sintetizador.darEfectoActual().darNombre());
			panelInformacion.actualizar(sintetizador.darEfectoActual().darDescripcion()
   				 , ""+ sintetizador.darEfectoActual().darCalificacion());
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog( this, e.getMessage( ), "Ver efecto anterior", JOptionPane.WARNING_MESSAGE );
		}
		 
		
					
			
		}
		public void darSiguiente() throws Exception{
			try{
			sintetizador.darSiguienteEfecto();
			Efecto efectoActual=sintetizador.darEfectoActual();
			panelSuperior.actualizar(efectoActual);
			System.out.println(sintetizador.darEfectoActual().darNombre());
			panelInformacion.actualizar(sintetizador.darEfectoActual().darDescripcion()
   				 , ""+ sintetizador.darEfectoActual().darCalificacion());
			}
			catch (Exception e){
				JOptionPane.showMessageDialog( this, e.getMessage( ), "Ver efecto anterior", JOptionPane.WARNING_MESSAGE );
			}
			
		}
		
		
		
		public void reproducir(String pNombreNota){
			sintetizador.reproducir(pNombreNota);
		}
		
		public void guardar(boolean pDivertidos, boolean pFantasia, boolean pFavoritos, String pCalificacion, String pDescripcion){
			
			
		
			sintetizador.guardarEfecto(pFavoritos, pFantasia, pDivertidos);
			panelInformacion.actualizar(pDescripcion, pCalificacion);
		}
			
			

		
		
		
	
	
	
	
	
	
	
	
	
	 /**
     * Busca el primer efecto. Si no hay ninguno informa al usuario.
     * 
     */
     public void buscarEfecto(){

    	 String pNombre = JOptionPane.showInputDialog(this, "Introduzca nombre del efecto");
    	 
    try{
    	 sintetizador.buscarPorNombre(pNombre);
    	 panelSuperior.actualizar(sintetizador.darEfectoActual());
    }catch(Exception e){
 	   JOptionPane.showMessageDialog( this, "No se encontr� ning�n efecto con ese nombre", "Buscar por nombre", JOptionPane.ERROR_MESSAGE );

    }
   

     }
     
     
     
     public void buscarCalificado(){
    	 
    		 sintetizador.buscarMejorCalificado();
    		 panelInformacion.actualizar(sintetizador.darEfectoActual().darDescripcion()
    				 , ""+ sintetizador.darEfectoActual().darCalificacion());
    	 
    	 
    	 
     }
     
     
     
     public Nota[] darNotas(){
    	return sintetizador.darNotas();
     }
     
     
     
     
     
     
     
     
     
     
     public void reqFuncOpcion1( )
     {
         String respuesta = sintetizador.metodo1( );
         JOptionPane.showMessageDialog( this, respuesta, "Respuesta", JOptionPane.INFORMATION_MESSAGE );
     }

     /**
      * Llamado para realizar el m�todo de extensi�n 2.
      */
     public void reqFuncOpcion2( )
     {
         String respuesta = sintetizador.metodo2( );
         JOptionPane.showMessageDialog( this, respuesta, "Respuesta", JOptionPane.INFORMATION_MESSAGE );
     }




	public static void main( String[] pArgs )
	{
		try
		{
			// Unifica la interfaz para Mac y para Windows.
			UIManager.setLookAndFeel( UIManager.getCrossPlatformLookAndFeelClassName( ) );

			InterfazSintetizador interfaz = new InterfazSintetizador( );
			interfaz.setVisible( true );
		}
		catch( Exception e )
		{
			e.printStackTrace( );
		}
	}}