 package uniandes.cupi2.sintetizador.interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PanelOpciones extends JPanel implements ActionListener 
{
	
	
	private static final String BUSCAR="Buscar por nombre";
	private static final String CALIFICADO="Buscar mejor calificado";
	private static final String CONTAR_EFECTOS="Contar efectos por grupo";
	
	
	
	private JButton buscarNombre;
	private JButton buscarCalificado;
	private JButton contarEfectos;
	private JButton opcion1;
	private JButton opcion2;
	private InterfazSintetizador sintetizador;
	
	
    public PanelOpciones(InterfazSintetizador pSintetizador) {
	
	
	sintetizador=pSintetizador;
	
	JPanel panelinferior=new JPanel();
	panelinferior.setLayout(new GridLayout(1, 5));
	setBorder(new TitledBorder("Opciones"));
	
	buscarNombre=new JButton(BUSCAR);
	buscarNombre.setActionCommand(BUSCAR);
	buscarNombre.addActionListener(this);
	
	
	buscarCalificado=new JButton(CALIFICADO);
	buscarCalificado.addActionListener(this);
	buscarCalificado.setActionCommand(CALIFICADO);
	
	contarEfectos=new JButton(CONTAR_EFECTOS);
	contarEfectos.addActionListener(this);
	contarEfectos.setActionCommand(CONTAR_EFECTOS);
	opcion1=new JButton("Opcion1");
	opcion1.addActionListener(this);
	opcion1.setActionCommand("Opcion1");
	opcion2 = new JButton("Opcion2");
	opcion2.addActionListener(this);
	opcion2.setActionCommand("Opcion2");
	
	
	add(panelinferior);
	panelinferior.add((buscarNombre));
	panelinferior.add((buscarCalificado));
	panelinferior.add((contarEfectos));
	panelinferior.add((opcion1));
	panelinferior.add((opcion2));
	
	
	
	
    }
    
	
	@Override
	public void actionPerformed(ActionEvent pEvento) {
		// TODO Auto-generated method stub
		String comando= pEvento.getActionCommand();
		if(comando.equals(BUSCAR)){
			sintetizador.buscarEfecto();
			}
		else if(comando.equals(CALIFICADO)){
			sintetizador.buscarCalificado();
			
		
		}
		
		
		// botones de opciones
		 else if( comando.equals("Opcion1" ) )
	        {
	            sintetizador.reqFuncOpcion1( );
	        }
	        else if( comando.equals( "Opcion2" ) )
	        {
	            sintetizador.reqFuncOpcion2( );
	        }
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	

}
