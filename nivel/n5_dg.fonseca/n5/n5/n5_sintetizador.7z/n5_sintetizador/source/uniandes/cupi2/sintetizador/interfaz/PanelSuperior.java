package uniandes.cupi2.sintetizador.interfaz;

import java.awt.event.ActionEvent;








import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import uniandes.cupi2.sintetizador.mundo.Efecto;

public class PanelSuperior  extends JPanel implements ActionListener {
	
	
	
	
	private static final String PIANOS ="./data/banners/sintetizador-0.png";
	private InterfazSintetizador sintetizador;
	private JLabel etiquetaImagen;
	
	
	
	
	public PanelSuperior (InterfazSintetizador pSintetizador){
		sintetizador=pSintetizador;
		
		etiquetaImagen=new JLabel();
		etiquetaImagen.setIcon(new ImageIcon(PIANOS));
		add(etiquetaImagen);
		 	
		
		
	}	
	
	
	
	public void actualizar(Efecto efectoActual){
		
		etiquetaImagen.setIcon(new ImageIcon(efectoActual.darRutaImagen()));
		
		
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
		
		
	}
	
	
	


